//
//  KKColors.h
//  KKMed
//
//  Created by Wang on 10/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#ifndef KKColors_h
#define KKColors_h

//color format
#define RGB(r, g, b)                                [UIColorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1];
#define RGBA(r, g, b, a)                            [UIColorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a];

#endif /* KKColors_h */
