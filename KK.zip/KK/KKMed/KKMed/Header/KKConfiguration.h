//
//  KKConfiguration.h
//  KKMed
//
//  Created by Wang on 10/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#ifndef KKConfiguration_h
#define KKConfiguration_h

//framework
#import "AFNetworking.h"


//category
#import "NSObject+KKNetworkingMethods.h"
#import "NSString+KKNetworkingMethods.h"
#import "NSArray+KKNetworkingMethods.h"
#import "NSSet+MSCategory.h"
#import "NSDictionary+KKNetworkingMethods.h"

#import "KKNetworkingConfiguration.h"
//local lib
#import "KKColors.h"
#import "KKImage.h"
#import "KKUserDefaults.h"
#endif /* KKConfiguration_h */
