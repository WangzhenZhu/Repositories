//
//  KKPUserDefaults.h
//  KKDoc
//
//  Created by Wang on 2018/7/4.
//  Copyright © 2018年 Wang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KKUserDefaults : NSObject

+ (instancetype)sharedInstance;

- (void)saveDeviceToken:(NSString *)deviceToken;
- (NSString *)deviceToken;

//- (NSNumber *)userID;

- (BOOL)isLogin;
- (void)signOut;

- (void)setVersion:(NSString *)version;
- (NSString *)version;


@end
