//
//  KKPUserDefaults.m
//  KKDoc
//
//  Created by Wang on 2018/7/4.
//  Copyright © 2018年 Wang. All rights reserved.
//

#import "KKUserDefaults.h"


@interface KKUserDefaults ()

@property (nonatomic, strong) NSUserDefaults *userDefaults;

@end

@implementation KKUserDefaults

+ (instancetype)sharedInstance
{
    static dispatch_once_t onceToken;
    static KKUserDefaults *instance = nil;
    dispatch_once(&onceToken, ^{
        instance = [[KKUserDefaults alloc] init];
    });
    return instance;
}

#pragma mark - getter and setters

- (NSUserDefaults *)userDefaults
{
    if (_userDefaults == nil) {
        _userDefaults = [NSUserDefaults standardUserDefaults];
    }
    return _userDefaults;
}

#pragma mark - DeviceToken

#define kDeviceToken @"DeviceToken"

- (void)saveDeviceToken:(NSString *)deviceToken
{
    [self.userDefaults setObject:deviceToken forKey:kDeviceToken];
    [self.userDefaults synchronize];
}

- (NSString *)deviceToken
{
    return [self.userDefaults objectForKey:kDeviceToken];
}

#pragma mark - Version

#define KKPVersion @"Version"

- (void)setVersion:(NSString *)version
{
    [self.userDefaults setObject:version forKey:KKPVersion];
    [self.userDefaults synchronize];
}

- (NSString *)version
{
    return [self.userDefaults objectForKey:KKPVersion];
}

#pragma mark - Login

- (BOOL)isLogin
{
    return YES;
}

- (void)signOut
{
    
}
@end
