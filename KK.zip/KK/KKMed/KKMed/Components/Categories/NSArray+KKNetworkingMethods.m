//
//  NSArray+KKNetworkingMethods.m
//  KKDoc
//
//  Created by Wang on 11/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import "NSArray+KKNetworkingMethods.h"
#import "NSSet+MSCategory.h"
#import "NSDictionary+KKNetworkingMethods.h"

@implementation NSArray (KKNetworkingMethods)

// 字母排序之后形成的参数字符串
- (NSString *)paramsString
{
    NSMutableString *paramString = [[NSMutableString alloc] init];
    NSArray *sortedParams = [self sortedArrayUsingSelector:@selector(compare:)];
    [sortedParams enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([paramString length] == 0) {
            [paramString appendFormat:@"%@",obj];
        } else {
            [paramString appendFormat:@"&%@",obj];
        }
    }];
    return paramString;
}

/** 数组变json */
- (NSString *)jsonString
{
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:self options:NSJSONWritingPrettyPrinted error:NULL];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

- (NSArray *)arrayWithCleanNSNullValue
{
    NSMutableArray* newArr = [@[] mutableCopy];
    [self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        if (![obj isKindOfClass:[NSNull class]])
        {
            if ([obj isKindOfClass:[NSDictionary class]])
            {
                [newArr addObject:[obj dictionaryWithCleanNSNullValue]];
            }
            else if ([obj isKindOfClass:[NSArray class]])
            {
                [newArr addObject:[obj arrayWithCleanNSNullValue]];
            }
            else if ([obj isKindOfClass:[NSSet class]])
            {
                [newArr addObject:[obj setWithCleanNSNullValue]];
            }
            else
            {
                [newArr addObject:obj];
            }
        }
    }];
    return [NSArray arrayWithArray:newArr];
}


@end
