//
//  KKBaseUrlConfiguration.h
//  KKMed
//
//  Created by Wang on 11/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KKBaseUrlConfiguration : NSObject

//url请求域名 (实际请求: baseUrl + 拼接url) 网络数据请求域名
@property (nonatomic, strong) NSString *baseUrl;

+ (instancetype)currentConfiguration;

@end
