//
//  KKBaseUrlConfiguration.m
//  KKMed
//
//  Created by Wang on 11/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import "KKBaseUrlConfiguration.h"

@implementation KKBaseUrlConfiguration

+ (instancetype)currentConfiguration
{
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = self.new;
    });
    return instance;
}

- (instancetype)init
{
    if (self = [super init]) {
        _baseUrl = @"";
    }
    return self;
}
@end
