//
//  NetWorkingManager.m
//  KKDoc
//
//  Created by Wang on 10/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import "NetWorkingManager.h"
#import "AFURLRequestSerialization.h"
#import "AFHTTPSessionManager.h"
#import "AFURLResponseSerialization.h"
#import "KKConfiguration.h"

@interface NetWorkingManager()
@property (nonatomic, strong) AFHTTPSessionManager *sessionManager;   //通用会话管理器
@end

@implementation NetWorkingManager

// 创建及获取单例对象的方法
// return 管理请求的单例对象的方法
+ (instancetype)sharedManager
{
    static NetWorkingManager *manager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[NetWorkingManager alloc] init];
    });
    return manager;
}

- (instancetype)init
{
    if (self = [super init]) {
        [self initSessionManager];
    }
    return self;
}

- (void)initSessionManager
{
    // 通用请求会话管理器
    //设置全局会话管理实例
    _sessionManager = [[AFHTTPSessionManager alloc] init];
    
    //设置请求序列化器， 解析json对象
    AFJSONRequestSerializer *requestSerializer = [AFJSONRequestSerializer serializer];
    requestSerializer.cachePolicy = NSURLRequestUseProtocolCachePolicy;
    requestSerializer.timeoutInterval = KKNetworkingTimeoutSeconds;
    _sessionManager.requestSerializer = requestSerializer;
    
    //设置响应序列化器，解析json对象
    AFJSONResponseSerializer *responseSerializer = [AFJSONResponseSerializer serializerWithReadingOptions:NSJSONReadingMutableContainers];
    responseSerializer.removesKeysWithNullValues = YES;
    responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/x-javascript", @"application/json", @"text/json", @"text/javascript", @"text/html",  nil];//设置接受数据格式
    _sessionManager.responseSerializer = responseSerializer;
    
    self.sessionManager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    
}

- (NSURLSessionDataTask *)callApiWithUrl:(NSString *)url headerParams:(NSDictionary *)headerParams params:(NSDictionary *)params requestType:(KKAPIManagerRequestType)requestType success:(KKRequestCallback)success fail:(KKRequestCallback)fail
{
    // url 长度为0，返回错误
    if ( !url || url.length == 0)
    {
        if (fail)
        {
            fail(nil, KKAPIManagerErrorTypeInvalidURL);
            
        }
        return nil;
    }
    //会话管理对象为空时
    if (!_sessionManager) {
        [self initSessionManager];
    }
    
    //请求成功时的回调
    void (^successWrap)(NSURLSessionDataTask * _Nonnull task,id _Nullable responseObject) = ^(NSURLSessionDataTask * _Nonnull task,id _Nullable responseObject) {
        //清理数据中的 nsnull对象
        responseObject = [responseObject dictionaryWithCleanNSNullValue];
        if (!responseObject || (![responseObject isKindOfClass:[NSDictionary class]] && ![responseObject isKindOfClass:[NSArray class]])) {
            if (fail)
            {
                fail(nil, KKAPIManagerErrorTypeNoContent);
            }
        }
        else //若解析数据正确，判断API返回的code
        {
         //   NSNumber *error = [responseObject objectForKey:@"error"];
            
            if (success) {
                success(responseObject, KKAPIManagerErrorTypeSuccess);
            }
        }
    };
    //请求失败时的回调
    void (^failureWrap)(NSURLSessionDataTask * _Nullable task,id _Nullable responseObject) = ^(NSURLSessionDataTask * _Nonnull task,id _Nullable responseObject) {
        if (fail) {
            AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
            fail(nil, manager.isReachable ? KKAPIManagerErrorTypeTimeout : KKAPIManagerErrorTypeNoNetWork);
            
        }
    };
    [self formatRequestHeaderWithHeaderParams:headerParams];
    
    //分离URL中的参数信息，重建参数列表
    params = [self formatParametersForURL:url withParams:params];
    url = [url componentsSeparatedByString:@"?"][0];;
    __block NSURLSessionDataTask *urlSessionDataTask;
    
    if (requestType == KKAPIManagerRequestTypePost) { //Post请求
        //检查url url中如果有汉字、空格、反斜杠等无法识别，就为nil
        if (![NSURL URLWithString:url]) {
            url = [url stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        }
        
        urlSessionDataTask = [_sessionManager POST:url
                                        parameters:params
                                          progress:nil
                                           success:successWrap
                                           failure:failureWrap];
    }
    else if (requestType == KKAPIManagerRequestTypeGet) //Get请求
    {
        //检查url url中如果有汉字、空格、反斜杠等无法识别，就为nil
        if (![NSURL URLWithString:url]) {
            url = [url stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        }
        
        urlSessionDataTask = [_sessionManager GET:url
                                       parameters:params
                                         progress:nil
                                          success:successWrap
                                          failure:failureWrap];
    }
    return urlSessionDataTask;

}

- (AFSecurityPolicy *)creatCustomPolicy
{
    AFSecurityPolicy *policy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    policy.allowInvalidCertificates = YES;
    return policy;
}
//请求参数处理
- (NSDictionary *)formatParametersForURL:(NSString *)url withParams:(NSDictionary *)params
{
    //清除参数中的NuNull对象
    NSMutableDictionary *fixedParams = [(params? [params dictionaryWithCleanNSNullValue]:@{}) mutableCopy];
    
    //分离URL中的参数信息
    NSArray *urlComponents = [[url stringByReplacingOccurrencesOfString:@" " withString:@""] componentsSeparatedByString:@"?"];
    NSArray *paramsCompones = urlComponents.count >= 2 && [urlComponents[1] length] > 0 ? [urlComponents[1] componentsSeparatedByString:@"&"] : nil;
    [paramsCompones enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSArray *paramComponets = [obj componentsSeparatedByString:@"="];
        if (!fixedParams[paramsCompones[0]]) {
            [fixedParams setObject:(paramComponets.count>=2 ?paramComponets[1] : @"") forKey:paramsCompones[0]];
        }
    }];
    //检查 param的个数，为0时，置为nil
    fixedParams = fixedParams.allKeys.count ? fixedParams : nil;
    return [fixedParams copy];
}


//请求头
- (void)formatRequestHeaderWithHeaderParams:(NSDictionary *)headerParams
{
    for (NSString *key in headerParams) {
        [_sessionManager.requestSerializer setValue:[headerParams objectForKey:key] forHTTPHeaderField:key];
    }
}
@end
