//
//  KKAPIBaseManager.m
//  KKMed
//
//  Created by Wang on 11/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import "KKAPIBaseManager.h"
#import "KKConfiguration.h"
//DEBUG 时 打印出相应请求数据

#ifdef DEBUG
#define MSRequestLog(__ViewControllerName_, __Url_, __Type_, __Params_, __ResponseData_) \
fprintf(stderr, "\n\n================ 数据请求成功(%s): ================\n",__ViewControllerName_.UTF8String); \
fprintf(stderr, "-- RequestUrl: %s\n", __Url_.UTF8String); \
fprintf(stderr, "-- Type: %s (0:Get 1:Post)\n", __Type_.UTF8String); \
if (__Params_) {\
fprintf(stderr, "-- Params: %s\n", [NSString stringWithFormat:@"%@", __Params_].UTF8String); \
} \
if (__ResponseData_) {\
fprintf(stderr, "-- ResponseData: %s\n", [NSString stringWithFormat:@"%@", __ResponseData_].UTF8String); \
}\
fprintf(stderr, "================================================\n\n");
#else
#define MSRequestLog(__ViewControllerName_,__Url_, __Type_, __Params_, __ResponseData_)
#endif

@interface KKAPIBaseManager()

@property (nonatomic, readwrite) KKAPIManagerErrorType errorType;

@property (nonatomic, strong) NSMutableDictionary *params;

@property (nonatomic, strong) NSURLSessionTask *task;

@property (nonatomic, strong) NSMutableDictionary *headerParams;

@end

@implementation KKAPIBaseManager

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.delegate = nil;
        self.paramsSource = nil;
        self.task = nil;
        self.params = nil;
        self.errorType = KKAPIManagerErrorTypeDefault;
        self.responseObject = nil;
    }
    return self;
}

- (void)loadData
{
    [self headerParamsWithDefaultData];
    self.params = [[NSMutableDictionary alloc]initWithDictionary:[self reformParams]];
    NSDictionary *headerReformDic = [self reformHeaderParams];
    for (NSString *key in [headerReformDic allKeys]) {
        [self.headerParams setObject:[headerReformDic objectForKey:key] forKey:key];
    }
    
    if (self.paramsSource) {
        if ([self.paramsSource respondsToSelector:@selector(paramForApi:)]) {
            NSDictionary *dic = [self.paramsSource paramForApi:self];
            for (NSString *key in [dic allKeys]) {
                [self.params setObject:[dic objectForKey:key] forKey:key];
            }
        }
        if ([self.paramsSource respondsToSelector:@selector(headerParamsForApi:)]) {
            NSDictionary *dic = [self.paramsSource headerParamsForApi:self];
            for (NSString *key in [dic allKeys]) {
                [self.headerParams setObject:[dic objectForKey:key] forKey:key];
            }
        }
    }
    
    __weak __typeof(self)weakSelf = self;
    self.task = [[NetWorkingManager sharedManager] callApiWithUrl:self.requestUrl headerParams:self.headerParams params:self.params?:@{} requestType:self.requestType success:^(id responseObject, KKAPIManagerErrorType errorType) {
         NSString * requestType = [NSString stringWithFormat:@"%lu",(unsigned long)weakSelf.requestType];
          MSRequestLog(NSStringFromClass([weakSelf class]), weakSelf.requestUrl, requestType, weakSelf.params, responseObject);
        if (weakSelf.delegate) {
            if (errorType == KKAPIManagerErrorTypeSuccess) {
                weakSelf.errorType = KKAPIManagerErrorTypeSuccess;
                if ([weakSelf.delegate respondsToSelector:@selector(managerCallAPIDidSuccess:)]) {
                    weakSelf.responseObject = responseObject;
                    [weakSelf.delegate managerCallAPIDidSuccess:weakSelf];
                    weakSelf.task = nil;
                }
            }else {
                weakSelf.errorType = errorType;
                if ([weakSelf.delegate respondsToSelector:@selector(managerCallAPIDidFailed:)]) {
                    [weakSelf.delegate managerCallAPIDidFailed:weakSelf];
                    weakSelf.task = nil;
                }
            }
    
        }
    } fail:^(id responseObject, KKAPIManagerErrorType errorType) {
        NSLog(@"数据请求失败 %@ %@",weakSelf, responseObject);
        weakSelf.errorType = errorType;
        switch (weakSelf.errorType) {
            case KKAPIManagerErrorTypeNoNetWork:
                weakSelf.errorMessage = NSLocalizedStringFromTable(@"KKAPIManagerErrorTypeNoNetwork", @"KKMed", nil);
                break;
            case KKAPIManagerErrorTypeDefault:
                 weakSelf.errorMessage = NSLocalizedStringFromTable(@"KKAPIManagerErrorTypeDefault", @"KKMed", nil);
                break;
            case KKAPIManagerErrorTypeTimeout:
                weakSelf.errorMessage = NSLocalizedStringFromTable(@"KKAPIManagerErrorTypeTimeout", @"KKMed", nil);
                break;
            default:
                weakSelf.errorMessage = @"";
                break;
        }
        
        if (weakSelf.delegate) {
            if ([weakSelf.delegate respondsToSelector:@selector(managerCallAPIDidFailed:)]) {
                [weakSelf.delegate managerCallAPIDidFailed:weakSelf];
                weakSelf.task = nil;
            }
        }
    }];
}

- (NSDictionary *)reformParams {
    return nil;
}

- (NSDictionary *)reformHeaderParams {
    return nil;
}

- (void)headerParamsWithDefaultData
{
    self.headerParams = [[NSMutableDictionary alloc] init];
    [self.headerParams setObject:@"application/json" forKey:@"Content-Type"];
    //self.headerParams setObject:@"" forKey:<#(nonnull id<NSCopying>)#>
}

- (void)dealloc
{
    [self cancelAllRequest];
}

- (void)cancelAllRequest
{
    if (self.task) {
        NSLog(@"取消数据请求 %@ %@",self,self.task);
        [self.task cancel];
    }
}
@end
