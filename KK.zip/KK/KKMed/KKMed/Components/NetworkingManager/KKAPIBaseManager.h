//
//  KKAPIBaseManager.h
//  KKMed
//
//  Created by Wang on 11/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NetWorkingManager.h"
#import "KKBaseUrlConfiguration.h"

@class KKAPIBaseManager;

//让manager能够获取调用API所需的数据
@protocol KKAPIManagerParamSourceDelegate <NSObject>
@required
//
- (NSDictionary *)paramForApi:(KKAPIBaseManager *)manager;

@optional
//请求头部 数据 实现该代理方法, 则会使用该代理返回的字典追加到已有的请求头数据中 (如有相同的key则会使用返回数据 进行覆盖)

- (NSDictionary *)headerParamsForApi:(KKAPIBaseManager *)manager;
@end

//api回调
@protocol KKAPIManagerApiCallBackDelegate <NSObject>
@required
- (void)managerCallAPIDidSuccess:(KKAPIBaseManager *)manager;
- (void)managerCallAPIDidFailed:(KKAPIBaseManager *)manager;
@end

@interface KKAPIBaseManager : NSObject

@property (nonatomic, strong) NSString *requestUrl;

@property (nonatomic, assign) KKAPIManagerRequestType requestType;

@property (nonatomic, weak) id<KKAPIManagerApiCallBackDelegate> delegate;

@property (nonatomic, weak) id<KKAPIManagerParamSourceDelegate> paramsSource;

//错误信息
@property (nonatomic, strong) NSString *errorMessage;
@property (nonatomic, readonly) KKAPIManagerErrorType errorType;
//请求返回数据
@property (nonatomic, strong) id responseObject;

//使用loadData这个方法来请求数据,这个方法会通过param source来获取参数,这使得参数的生成逻辑位于controlelr中的固定位置
- (void)loadData;

//子类 重写这个方法，可以为某个接口统一设置参数信息
- (NSDictionary *)reformParams;

//统一设置请求头
- (NSDictionary *)reformHeaderParams;

@end
