//
//  KKColors.h
//  KKMed
//
//  Created by Wang on 10/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#ifndef KKColors_h
#define KKColors_h

//color format
#define RGB(r, g, b)                                [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:1]
#define RGBA(r, g, b, a)                            [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]
#define RGBACG(r, g, b, a)                          [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a].CGColor

#define ThemeColor                                  RGB(76,182,170)
#endif /* KKColors_h */
