//
//  KKImage.h
//  KKMed
//
//  Created by Wang on 10/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#ifndef KKImage_h
#define KKImage_h

//image format
#define IMG(name)                                       [UIImage imageNamed:name]

#endif /* KKImage_h */
