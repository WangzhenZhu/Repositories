//
//  NSObject+KKNetworkingMethods.h
//  KKMed
//
//  Created by Wang on 11/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (KKNetworkingMethods)

- (id)defaultValue:(id)defaultData;
- (BOOL)isEmptyObject;

@end
