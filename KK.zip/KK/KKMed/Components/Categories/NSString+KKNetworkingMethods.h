//
//  NSString+KKNetworkingMethods.h
//  KKMed
//
//  Created by Wang on 11/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface NSString (KKNetworkingMethods)

+ (instancetype)encodeBase64String:(NSString *)stringToEncode;
+ (instancetype)decodeBase64String:(NSString *)stringToDeccode;

- (NSString *)MD5;

+ (NSString *)trim:(NSString *)string;

+ (BOOL)isEmpty:(NSString *)string;
+ (BOOL)isUInteger:(NSString *)string;
+ (BOOL)isMobileNumber:(NSString *)mobileNum;
+ (BOOL)isPassword:(NSString *)password;
+ (BOOL)isAccount:(NSString *)account;
// 校验工商注册号  13-15位数字和字母
+ (BOOL)isbusinessNo:(NSString *)businessNo;
// 身份证号校验
+ (BOOL)isIdentityCard: (NSString *)identityCard;
// 邮箱校验
+ (BOOL)isEmail:(NSString *)email;
- (BOOL)isAllDigits;

- (BOOL)isMatchesRegExp:(NSString *)regExp;
- (CGSize)sizeWithFont:(UIFont *)font inScopeOfSize:(CGSize)constrainedSize;

/****** 计算字符串的像素长度 ******/
+(CGFloat)iStringLength:(NSString *)str font:(UIFont *)font;

/**
 *  DES 加密
 *
 *  @param plainText 待加密的字符串
 *  @param key       加密解密的key
 *
 *  @return 经过DES加密后的16进制字符串
 */
+ (NSString *)encryptUseDES:(NSString *)plainText key:(NSString *)key;

/**
 *  DES 解密
 *
 *  @param cipherText 待解密的16进制的字符串
 *  @param key        加密解密的key
 *
 *  @return 解密后的字符串
 */
+ (NSString *)decryptUseDES:(NSString*)cipherText key:(NSString*)key;

/**
 *  文本数据转成16进制字符串
 *
 *  @param data 待转换的文本数据
 *
 *  @return 16进制的字符串
 */
+ (NSString *)convertDataToHexStr:(NSData *)data;

/**
 *  16进制字符串转为文本数据
 *
 *  @param str 16进制的字符串
 *
 *  @return 待转换的文本数据
 */
+ (NSData *)convertHexStrToData:(NSString *)str;

+ (NSString *)getUniqueHardwareId;

/**
 *  把格式化的JSON格式的字符串转换成字典
 *
 *  @param jsonString jsonString JSON格式的字符串
 *
 *  @return 返回字典
 */
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString;

- (NSMutableDictionary *)getURLParameters;

/**
 *  判断number中是否全部为数字
 *
 *  @param number 待判断的字符串
 *
 *  @return 返回  全部为数字 YES
 */
+ (BOOL)validateNumber:(NSString*)number;


@end
