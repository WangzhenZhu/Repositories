//
//  UpDownSelectView.m
//  KKPat
//
//  Created by Wang on 19/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import "UpDownSelectView.h"

@interface UpDownSelectView()

@property (nonatomic, strong) UIButton *upBtn;
@property (nonatomic, strong) UIButton *downBtn;

@end
@implementation UpDownSelectView

- (instancetype)initWithFrame:(CGRect)frame
{
  self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.upBtn];
        [self addSubview:self.downBtn];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    [self.upBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(self.mas_left);
        make.right.equalTo(self.mas_right);
        make.height.equalTo(self.mas_height).multipliedBy(0.5);
    }];
    [self.downBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.mas_bottom);
        make.left.equalTo(self.mas_left);
        make.right.equalTo(self.mas_right);
        make.height.equalTo(self.mas_height).multipliedBy(0.5);
    }];
}

- (UIButton *)upBtn
{
    return _upBtn;
}

- (UIButton *)downBtn
{
    return _downBtn;
}
@end
