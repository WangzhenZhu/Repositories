//
//  KKPUserDefaults.h
//  KKDoc
//
//  Created by Wang on 2018/7/4.
//  Copyright © 2018年 Wang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KKUserDefaults : NSObject

+ (instancetype)sharedInstance;

- (void)saveDeviceToken:(NSString *)deviceToken;
- (NSString *)deviceToken;

//- (NSNumber *)userID;

//- (BOOL)isLogin;
//- (void)setisLogin:(BOOL)login;
//- (void)signOut;

- (void)setVersion:(NSString *)version;
- (NSString *)version;

- (void)saveValue:(id) value forKey:(NSString *)key;
- (id)valueWithKey:(NSString *)key;

- (void)setBoolValue:(BOOL)value withKey:(NSString *)key;
- (BOOL)boolValueWithKey:(NSString *)key;
@end
