//
//  KKPatTabBar.h
//  KKPat
//
//  Created by Wang on 20/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KKPatTabBar : UITabBar

@property (nonatomic, strong) UIImageView *BgView;
@end
