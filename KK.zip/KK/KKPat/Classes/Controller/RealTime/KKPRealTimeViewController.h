//
//  KKPRealTimeViewController.h
//  KKPat
//
//  Created by Wang on 21/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import "KKPBaseViewController.h"

@interface KKPRealTimeViewController : KKPBaseViewController

@end
