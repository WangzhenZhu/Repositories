//
//  KKPBaseViewController.h
//  KKPat
//
//  Created by Wang on 2018/7/3.
//  Copyright © 2018年 Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KKPBaseViewController : UIViewController

@end
