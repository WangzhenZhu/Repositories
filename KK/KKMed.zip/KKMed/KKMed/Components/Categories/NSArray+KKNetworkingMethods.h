//
//  NSArray+KKNetworkingMethods.h
//  KKDoc
//
//  Created by Wang on 11/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (KKNetworkingMethods)

- (NSString *)paramsString;
- (NSString *)jsonString;
- (NSArray *)arrayWithCleanNSNullValue;
@end
