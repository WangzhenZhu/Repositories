//
//  NSDictionary+KKNetworkingMethods.h
//  KKMed
//
//  Created by Wang on 11/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (KKNetworkingMethods)

- (NSString *)urlParamsStringSignature:(BOOL)isForSignature;
- (NSString *)jsonString;
- (NSArray *)transformedUrlParamsArraySignature:(BOOL)isForSignature;
- (NSDictionary *)dictionaryWithCleanNSNullValue;
@end
