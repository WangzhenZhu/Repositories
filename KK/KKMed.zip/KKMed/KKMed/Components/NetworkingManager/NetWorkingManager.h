//
//  NetWorkingManager.h
//  KKDoc
//
//  Created by Wang on 10/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import <Foundation/Foundation.h>

//网络请求类型
typedef NS_ENUM(NSUInteger, KKAPIManagerRequestType) {
    KKAPIManagerRequestTypeGet = 0,         //get请求
    KKAPIManagerRequestTypePost = 1,        //Post请求
};

//网络请求错误类型
typedef NS_ENUM(NSUInteger, KKAPIManagerErrorType) {
    KKAPIManagerErrorTypeDefault = 0,       //没有产生API请求 ，默认状态
    KKAPIManagerErrorTypeSuccess,
    KKAPIManagerErrorTypeNoContent,         //请求成功。但请求数据不对
    KKAPIManagerErrorTypeParamError,        //参数错误
    KKAPIManagerErrorTypeTimeout,            //请求超时20秒
    KKAPIManagerErrorTypeNoNetWork,         //网络不通，在请求之前验证
    KKAPIManagerErrorTypeInvalidURL         //请求失败，无效URL
    
};

typedef void (^KKRequestCallback)(id responseObject, KKAPIManagerErrorType errorType);

@interface NetWorkingManager : NSObject

+ (instancetype)sharedManager;

- (NSURLSessionDataTask *)callApiWithUrl:(NSString *)url headerParams:(NSDictionary *)headerParams params:(NSDictionary *)params requestType:(KKAPIManagerRequestType)requestType success:(KKRequestCallback)success fail:(KKRequestCallback)fail;
@end
