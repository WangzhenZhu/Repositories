//
//  KKNetworkingConfiguration.h
//  KKMed
//
//  Created by Wang on 10/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#ifndef KKNetworkingConfiguration_h
#define KKNetworkingConfiguration_h

static NSInteger kAppVersion                    = 1;

static NSTimeInterval KKNetworkingTimeoutSeconds = 10.0f;

static NSInteger KKPinTimeInterval               = 60;//短信验证码时间间隔
static NSString *KKPinCode                       = @"000000";

static NSInteger kERPageSize                      = 10;//列表每页显示个数


#endif /* KKNetworkingConfiguration_h */
