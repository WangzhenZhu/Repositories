//
//  EntryInfoViewController.m
//  KKPat
//
//  Created by Wang on 17/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import "EntryInfoViewController.h"
#import "KKConfiguration.h"
#import "EntryInfoView.h"



@interface EntryInfoViewController ()


@end

@implementation EntryInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   // self.automaticallyAdjustsScrollViewInsets = false;
    self.view.backgroundColor = ThemeColor;

 
}





@end
