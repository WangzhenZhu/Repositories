//
//  illnessNameCell.m
//  KKPat
//
//  Created by Wang on 18/07/2018.
//  Copyright © 2018 Wang. All rights reserved.
//

#import "illnessNameCell.h"

@interface illnessNameCell()

@property (weak, nonatomic) IBOutlet UIView *illnessBgView;
@end
@implementation illnessNameCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.illnessBgView.layer.cornerRadius = 6.f;
    self.illnessBgView.layer.masksToBounds = YES;
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
